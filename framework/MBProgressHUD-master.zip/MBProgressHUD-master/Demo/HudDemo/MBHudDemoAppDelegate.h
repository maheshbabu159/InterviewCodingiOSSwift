//
//  MBHudDemoAppDelegate.h
//  HudDemo
//
//  Created by Matej Bukovinski on 2.4.09.
//  Copyright © 2009-2016 Matej Bukovinski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MBHudDemoAppDelegate : NSObject <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
